<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
	$cart_url = wc_get_cart_url();
?>
<p class="lucky-dip-text">
	<?php _e( 'Oops, something went wrong. Please try again.',  'wc-lottery-pn' ); ?>
</p>
