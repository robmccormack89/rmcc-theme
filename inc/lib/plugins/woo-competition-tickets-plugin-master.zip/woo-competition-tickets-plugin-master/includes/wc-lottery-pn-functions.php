<?php

function wc_lottery_pn_get_taken_numbers( $product_id = false, $user_id = false ) {
	global $product;

	$wheredatefrom = '';

	if ( ! $product_id && $product ) {
			$product_id = $product->get_id();
	}
	global $wpdb;

	$relisteddate = get_post_meta( $product_id, '_lottery_relisted', true );

	if ( $relisteddate ) {
		$wheredatefrom = ' AND CAST(' . $wpdb->prefix . "wc_lottery_log.date AS DATETIME) > '$relisteddate' ";
	}

	$result = $wpdb->get_col( $wpdb->prepare( 'SELECT ' . $wpdb->prefix . 'wc_lottery_pn_log.ticket_number FROM ' . $wpdb->prefix . 'wc_lottery_pn_log LEFT JOIN ' . $wpdb->prefix . 'wc_lottery_log ON ' . $wpdb->prefix . 'wc_lottery_log.id = ' . $wpdb->prefix . 'wc_lottery_pn_log.log_id WHERE ' . $wpdb->prefix . 'wc_lottery_pn_log.lottery_id = %d ' . $wheredatefrom, $product_id ) );

	return $result;
}


function wc_lottery_pn_get_reserved_numbers( $product_id = false, $session_key = false ) {
	global $product;

	if ( ! $product_id && $product ) {
			$product_id = $product->get_id();
	}
	global $wpdb;

	$minutes = get_option( 'lottery_answers_reserved_minutes', '5' );

	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . $wpdb->prefix . 'wc_lottery_pn_reserved WHERE date < (NOW() - INTERVAL %d MINUTE)', $minutes ) );

	if( ! $session_key ){
		$result = $wpdb->get_col( $wpdb->prepare( 'SELECT ' . $wpdb->prefix . 'wc_lottery_pn_reserved.ticket_number FROM ' . $wpdb->prefix . 'wc_lottery_pn_reserved  WHERE ' . $wpdb->prefix . 'wc_lottery_pn_reserved.lottery_id = %d ', $product_id ) );
	} else {
		$result = $wpdb->get_col( $wpdb->prepare( 'SELECT ' . $wpdb->prefix . 'wc_lottery_pn_reserved.ticket_number FROM ' . $wpdb->prefix . 'wc_lottery_pn_reserved  WHERE ' . $wpdb->prefix . 'wc_lottery_pn_reserved.lottery_id = %d AND session_key != %s', $product_id, $session_key ) );
	}

	return $result;
}


function wc_lottery_pn_get_true_answers( $product_id = false ) {
	global $product;

	$answers_id = array();

	if ( ! $product_id && $product ) {
			$product_id = $product->get_id();
	}

	$answers = maybe_unserialize( get_post_meta( $product_id, '_lottery_pn_answers', true ) );

	if ( $answers ) {
		foreach ( $answers as $key => $answer ) {
			if ( 1 === $answer['true'] ) {
					$answers_id[ $key ] = $answer['text'];
			}
		}
	}

	return $answers_id;
}


function wc_lottery_pn_get_ticket_numbers_from_cart( $product_id = false ) {
	$items          = WC()->cart->get_cart();
	$ticket_numbers = array();
	foreach ( $items as $key => $value ) {
		if ( isset( $ticket_numbers[ $value['product_id'] ] ) ) {
			$ticket_numbers[ $value['product_id'] ] = array_merge( $ticket_numbers[ $value['product_id'] ], $value['lottery_tickets_number'] );
		} elseif ( isset( $value['lottery_tickets_number'] ) ) {
			$ticket_numbers[ $value['product_id'] ] = $value['lottery_tickets_number'];
		}
	}
	if ( $product_id ) {
		return isset( $ticket_numbers[ $product_id ] ) ? $ticket_numbers[ $product_id ] : array();
	}
	return $ticket_numbers;
}


function wc_lottery_use_answers( $product_id = false ) {

	global $product;

	if ( ! $product_id && $product ) {
			$product_id = $product->get_id();
	}

	$use_answers = get_post_meta( $product_id, '_lottery_use_answers', true );

	if ( 'yes' !== $use_answers ) {
		return false;
	}

	$lottery_question = get_post_meta( $product_id, '_lottery_question', true );

	if ( ! $lottery_question ) {
		return false;
	}

	$answers = maybe_unserialize( get_post_meta( $product_id, '_lottery_pn_answers', true ) );
	if ( ! $answers ) {
		return false;
	}

	return true;
}


function wc_lottery_generate_random_ticket_numbers( $product_id, $qty ) {

	$random_tickets = array();

	$available_tickets= wc_lotery_get_available_ticket( $product_id );

	if( empty( $available_tickets ) || count( $available_tickets ) < $qty ) {
		return false;
	}

	$random_tickets =   (array) array_rand( array_flip ($available_tickets) , $qty);

	if( !empty( $random_tickets ) ){

		$session_key = WC()->session->get_customer_id();

		foreach ($random_tickets as $value) {
			wc_lottery_reserve_ticket($product_id, $value, $session_key);
		}
	} 

	if ( empty( $random_tickets ) ){
		return false;
	}
	
	return $random_tickets;
}


function wc_lottery_reserve_ticket( $lottery_id, $ticket_number, $session_key) {

	global $wpdb;

	$log_bid = $wpdb -> insert($wpdb -> prefix . 'wc_lottery_pn_reserved', array('lottery_id' => $lottery_id, 'ticket_number' => $ticket_number, 'session_key' => $session_key ), array('%d', '%d', '%s'));

	return $log_bid;
}


function lottery_get_int_number_from_alphabet($alphabet_number , $product){

	if( ! $product ) {
		return $alphabet_number;
	}

	$tabnumbers = get_post_meta( $product->get_id() , '_lottery_pick_number_tab_qty', true );

	$tabnumbers = $tabnumbers ? intval( $tabnumbers )  : 100;

	$alphabet = array_flip  ( range('A', 'Z') );

	$letter = $alphabet_number[0];

	$in = $alphabet[$letter];

	$first_digits= $in;

	$add_numbers = $in * $tabnumbers;
	
	$int_ticket_number = intval( $add_numbers + intval( substr($alphabet_number, 1) ) );	

	return $int_ticket_number;
}


function wc_lotery_get_available_ticket( $product_id ) {

	$taken_numbers = wc_lottery_pn_get_taken_numbers( $product_id );

	$reserved_numbers = wc_lottery_pn_get_reserved_numbers( $product_id );

	$tickets_from_cart = wc_lotery_get_tickets_from_cart( $product_id );

	$max_tickets = intval( get_post_meta( $product_id, '_max_tickets', true ) );

	$tickets = range(1, $max_tickets);

	$available_tickets= array_diff ($tickets,$taken_numbers, $reserved_numbers, $tickets_from_cart);

	return $available_tickets;
}


function wc_lotery_get_tickets_from_cart( $product_id ) {

	$tickets_in_cart = array();

	if ( ! WC()->cart->is_empty() ) {
		foreach(WC()->cart->get_cart() as $cart_item ) {
			if($product_id == $cart_item['product_id'] ){
				if( $cart_item['lottery_tickets_number'] && is_array( $cart_item['lottery_tickets_number'] ) ){
					$tickets_in_cart = array_merge($tickets_in_cart, $cart_item['lottery_tickets_number']);
				}
			}
			
		}
	}
	return $tickets_in_cart;

}
