// import uikit & icons
import UIkit from 'uikit';

// Make uikit available in window for inline scripts
window.UIkit = UIkit;