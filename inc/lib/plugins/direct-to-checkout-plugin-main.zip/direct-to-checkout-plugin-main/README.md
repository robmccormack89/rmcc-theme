# Direct to Checkout

Allows for an optimized woocommerce chekout experience. Dont't forget to disable the basket page in Woocommerce Settings -> Advanced.