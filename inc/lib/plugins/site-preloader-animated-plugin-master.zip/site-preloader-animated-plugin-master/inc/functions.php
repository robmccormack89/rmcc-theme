<?php

function preloader_html() {
  echo '<div id="ThemePreload" class="theme-preload"></div>';
}