# Site Animated Preloader

Adds a preloader animation to the website @ rmmc_before_header with priority 5.