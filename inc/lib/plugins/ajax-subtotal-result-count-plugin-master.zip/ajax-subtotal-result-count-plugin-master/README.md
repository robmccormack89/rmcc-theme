# Ajax Subtotal & Result Count

Custom result count & subtotal amount for header. Works with ajax. Add via the shortcode: [rmcc_header_result_subtotal]