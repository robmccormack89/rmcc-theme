# Custom Store Notice

Modified Woocommerce Demo Store Notice - add_custom_demo_store_notice > rmcc_before_header > priority 10