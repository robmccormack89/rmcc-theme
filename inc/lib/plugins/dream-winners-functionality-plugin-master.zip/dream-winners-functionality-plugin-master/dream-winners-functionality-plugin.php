<?php
/*
Plugin Name: Dream Winners Theme Functionality by RMcC
Plugin URI: #
Description: Adds Competition Winners & Entry Lists content-types with custom templates to the Dream Winners Theme. Also adds related custom fields & Theme Settings backend page. This plugin comes with it's own Timber integration via composer. This plugin is translation-ready via plugins like Loco Translate.
Version: 1.0.0
Author: robmccormack89
Author URI: #
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE
Text Domain: dream-winners-functionality
Domain Path: /languages/
*/

// don't run if someone access this file directly
defined('ABSPATH') || exit;

// define some constants
if (!defined('DREAM_WINNERS_FUNCTIONALITY_PATH')) define('DREAM_WINNERS_FUNCTIONALITY_PATH', plugin_dir_path( __FILE__ ));
if (!defined('DREAM_WINNERS_FUNCTIONALITY_URL')) define('DREAM_WINNERS_FUNCTIONALITY_URL', plugin_dir_url( __FILE__ ));
if (!defined('DREAM_WINNERS_FUNCTIONALITY_BASE')) define('DREAM_WINNERS_FUNCTIONALITY_BASE', dirname(plugin_basename( __FILE__ )));

// require action functions 
// require_once('inc/functions.php');

// require the composer autoloader
if (file_exists($composer_autoload = __DIR__.'/vendor/autoload.php')) require_once $composer_autoload;

// then require the main plugin class. this class extends Timber/Timber which is required via composer
new Rmcc\DreamWinnersFunctionality;