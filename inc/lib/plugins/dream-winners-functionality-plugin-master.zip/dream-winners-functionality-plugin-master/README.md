# Dream Winners Theme Functionality by RMcC

Adds Competition Winners & Entry Lists content-types with custom templates to the Dream Winners Theme. Also adds related custom fields & Theme Settings backend page. This plugin comes with it's own Timber integration via composer. This plugin is translation-ready via plugins like Loco Translate.