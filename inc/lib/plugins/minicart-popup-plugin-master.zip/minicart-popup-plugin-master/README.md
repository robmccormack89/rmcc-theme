# Minicart & popup modal for Woocommerce

A custom woocommerce minicart with a uikit popup modal. Toggle the modal via #MiniCartModal.